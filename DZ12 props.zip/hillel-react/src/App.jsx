import React from "react";

import UserTemplate from "./components/user";


function App() {
  return (
    <>
    <UserTemplate/> 
    </>
    
  );
}

export default App;
