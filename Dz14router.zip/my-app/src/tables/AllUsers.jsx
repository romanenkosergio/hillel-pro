import React from "react";

const AllUsers = () => {
    return (
        <div className="all-users">
           <h1>All Users</h1>
        </div>    
       )
};

export default AllUsers;