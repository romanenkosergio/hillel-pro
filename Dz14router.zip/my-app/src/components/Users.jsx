import React, {useEffect, useState} from "react";

import Card from "./Card";

const Users = () => {
    const [users, setUsers] = useState([]);

    const fetchUsers = async () => {
        try {
            const resp = await fetch('https://jsonplaceholder.typicode.com/users');
            const data = await resp.json();
            const array = Array.from(data);
         setUsers(array)
        }catch (e){
            console.log(e);
          }
    };

    useEffect( () => {
        fetchUsers();
    }, []);

    return (
        <div className="users">
            <div className={"users-list"}>
                {users?.map((user) => {
                    return (
                        <Card user={[user.phone, user.name, user.id, user.username, user.email, user.website, user.address, user.company]} key={[user.id]}/>
                      );
                    })}
            </div>
        </div>
    )
};

export default Users;