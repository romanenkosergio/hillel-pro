import React from "react";

const UserInfo = ({text}) => {
    return (
        <div className="user__info">
            <span>Full name: {text}</span>
        </div>
    )
};

export default UserInfo;