import React, { useEffect, useState } from 'react';

import {useParams} from 'react-router-dom';


const User = () => {

   const params = useParams();
   const [user, setUser] = useState(null);
   
   useEffect(() => {
      if(params?.id) {
      fetch(`https://jsonplaceholder.typicode.com/posts/`)
      .then(out => out.json())
      .then(devider => {
        let sortedArray = [];
       for(let i = 0; i < devider.length; i+= 10) {
            const result = devider.slice(i, i + 10);
            sortedArray.push(result);
       }
       return sortedArray;
      })
      .then(outcome => outcome[params.id])
      .then(data => setUser(data))
      }
    }, []);
            return (
                <div className="user">
                    {user?.map(userRelated => {
                    return (
                        <div className="user_related" key={userRelated.id}>
                            <h1>ID: {userRelated?.id}</h1>
                            <p>User ID - <strong style={{color:"coral"}}>{userRelated?.userId}</strong></p>
                            <p><strong>Title:</strong> {userRelated?.title}</p>
                            <div className='product-list'></div>
                            <p style={{fontFamily:"cursive"}}>{userRelated?.body}</p>
                        </div>
                       );
                    })}
                </div>  
            );
};

export default User;