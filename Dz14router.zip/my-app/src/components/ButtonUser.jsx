import React from "react";

const ButtonUser = ({text}) => {
    return (
        <button className="card_button" type="button">
           <span className="card-button_text">{text}</span>
        </button>
    )
};

export default ButtonUser;