import React from "react";
import { useNavigate, Navigate } from "react-router-dom";

import UserInfo from "./UserInfo";

const Card = ({user}) => {
    
    const navigateId = useNavigate();

    const handleNavigate = () => {
        navigateId(`/users/${user[2]-1}`)
    };

    return (
        <div className="card">
            <div className="card__id">
                <p>ID: {user[2]}</p>
            <div/>
            </div>
            <div className="card__contact">
                <UserInfo text={user[1]}/>
                <div className="card_more">
                    <div className="card_more card-address"> 
                        <p><strong>Address:</strong></p>
                        <p>{user[6].street}, {user[6].suite}</p>
                        <p>{user[6].city} {user[6].zipcode}</p>
                        <p><strong>Phone:</strong> {user[0]}</p>
                    </div>
                    <div className="card_more card-copmany">
                         <p><strong>Company name:</strong></p>
                         <p>{user[7].name}</p>
                         <p>{user[7].bs}</p>
                         <p><strong>Slogan</strong> - <em>"{user[7].catchPhrase}"</em></p>
                    </div>
                    <div className="card_more card-electronic-info">
                        <p><strong>Username:</strong> {user[3]}</p>
                        <p><strong>Email:</strong> {user[4]}</p>
                        <p><strong>Website:</strong> <a href="/">{user[5]}</a></p>
                    </div>
                </div>
            </div>  
           <button className="card_button" onClick={handleNavigate}>Show userinfo</button>
       </div>
    )
};

export default Card;